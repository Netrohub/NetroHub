<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class TurnstileService
{
    public function verifyToken(?string $token, string $ip = null): bool
    {
        if (empty($token)) return false;

        $secret = config('services.turnstile.secret_key');
        if (empty($secret)) return false;

        $resp = Http::timeout(5)->asForm()->post(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify',
            [
                'secret'   => $secret,
                'response' => $token,
                'remoteip' => $ip,
            ]
        );

        if (! $resp->ok()) return false;

        $json = $resp->json();
        return (bool)($json['success'] ?? false);
    }
}